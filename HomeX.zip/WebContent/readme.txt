We have 11 html pages (except navbar.html) which most of them gonna be JSP files in future.

/////////////////////////////////////////////
index
--------------------------------------------
this page is to search for property and the Find Home tap in the navbar must be linked to this page
////////////////////////////////////////////


/////////////////////////////////////////////
login
--------------------------------------------
this page for user to login by using email and password
////////////////////////////////////////////


/////////////////////////////////////////////
register
--------------------------------------------
this page for new user registration by using email and new password and date of birth
////////////////////////////////////////////


/////////////////////////////////////////////
admin
--------------------------------------------
this page shows requests from user who want to add new property with confirm and reject buttons
////////////////////////////////////////////


/////////////////////////////////////////////
profile
--------------------------------------------
this page shows presonal information of the user along with his/her offered properties also with the property he would like to rent from other users.
 Moreover, it has :
 -edit profile button to go to edit.profile page
 -contact owner buttin to go to chat page
 -cancel reservation button
 -edit his/her own property which will take user to edit.profile page
 -add his/her own property which will take user to new.property page
////////////////////////////////////////////


/////////////////////////////////////////////
chat
--------------------------------------------
this page where a user can chat with owner after he/she make reservation
////////////////////////////////////////////


/////////////////////////////////////////////
edit.profile
--------------------------------------------
this page to edit profile page by adding only extra information like: user name and phone number also his/her own picture
////////////////////////////////////////////


/////////////////////////////////////////////
search.result
--------------------------------------------
this will be displayed after the user click search button in index page
////////////////////////////////////////////


/////////////////////////////////////////////
view.property
--------------------------------------------
after user see all offers in search.result page he can view each offer in this page, also can make reservation by clicking the bottom button
////////////////////////////////////////////


/////////////////////////////////////////////
new.property
--------------------------------------------
once the user clicks the new property button, he/she can add new property in this page
////////////////////////////////////////////


/////////////////////////////////////////////
contact.us
--------------------------------------------
everything about website will be displayed in this page
////////////////////////////////////////////
